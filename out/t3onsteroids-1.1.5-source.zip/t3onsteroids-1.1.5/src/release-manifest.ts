import { compatibility } from "./compatibility.js";

export type V1ReleaseGateStatus = "pending" | "pass";

export interface V1ReleaseGate {
  readonly status: V1ReleaseGateStatus;
  readonly evidencePath: string;
}

export interface CosProviderExtensionGate extends V1ReleaseGate {
  readonly extensionBuildId: typeof compatibility.cos.providerExtension.buildId | null;
  readonly featureVersions: typeof compatibility.cos.providerExtension.features;
}

export interface T3HeadDriftGate extends V1ReleaseGate {
  readonly outcome: "compatible" | "incompatible" | null;
}

export interface V1ReleaseGateManifest {
  readonly schemaVersion: 1;
  /**
   * The exact T3 source baseline the live release gates were recorded against. Qualification is
   * tuple-specific: moving the pinned development baseline to a different T3 commit keeps every
   * historical gate green but revokes the release claim until live acceptance is rerun and this
   * field is promoted with new evidence.
   */
  readonly qualifiedT3Sha: string;
  readonly gates: Readonly<{
    cosProviderExtension: CosProviderExtensionGate;
    eventTranslator: V1ReleaseGate;
    durableRecovery: V1ReleaseGate;
    acpStdio: V1ReleaseGate;
    controllerPrivacy: V1ReleaseGate;
    toolchainAudit: V1ReleaseGate;
    performance: V1ReleaseGate;
    liveAcceptance: V1ReleaseGate;
    t3HeadDrift: T3HeadDriftGate;
    releasePreparation: V1ReleaseGate;
  }>;
}

export const v1ReleaseGateManifest: V1ReleaseGateManifest = {
  schemaVersion: 1,
  // The v1.0.0 release tuple. Deliberately separate from `compatibility.t3`, which tracks the
  // pinned development baseline and may move ahead of the last live-qualified build.
  qualifiedT3Sha: "ffb4af8d5d4fcfc5e9322295ff846a6d1e7ffbf8",
  gates: {
    cosProviderExtension: {
      status: "pass",
      evidencePath: "docs/evidence/v1-01-cos-extension.md",
      extensionBuildId: compatibility.cos.providerExtension.buildId,
      featureVersions: compatibility.cos.providerExtension.features,
    },
    eventTranslator: { status: "pass", evidencePath: "docs/evidence/v1-02-event-translator.md" },
    durableRecovery: { status: "pass", evidencePath: "docs/evidence/v1-03-durable-recovery.md" },
    acpStdio: { status: "pass", evidencePath: "docs/evidence/v1-04-acp-stdio.md" },
    controllerPrivacy: { status: "pass", evidencePath: "docs/evidence/v1-05-controller-privacy.md" },
    toolchainAudit: { status: "pass", evidencePath: "docs/evidence/v1-06-toolchain-audit.md" },
    performance: { status: "pass", evidencePath: "docs/evidence/v1-07-performance.md" },
    liveAcceptance: { status: "pass", evidencePath: "docs/evidence/v1-08-acceptance.md" },
    t3HeadDrift: { status: "pass", evidencePath: "docs/evidence/v1-09-release.md", outcome: "compatible" },
    releasePreparation: { status: "pass", evidencePath: "docs/evidence/v1-09-release.md" },
  },
};
